
#!/usr/bin/env python3
"""implant_sim.py - Simulated implant client for hippocampus demo.
This script simulates a secure implant connecting to hippocampus.py.
It performs:
- X25519 ephemeral key exchange
- Ed25519 attestation signature over (client_xpub || device_pub || nonce)
- Establishes AEAD channel and exchanges messages
"""

import socket, os, json, struct, secrets, time
from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey, X25519PublicKey
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives.ciphers.aead import ChaCha20Poly1305

HOST='127.0.0.1'
PORT=9000
KEY_DIR = '/mnt/data/hippocampus_secure_demo/keys'
os.makedirs(KEY_DIR, exist_ok=True)

device_id = 'device-demo-001'
device_priv_path = os.path.join(KEY_DIR, 'device_ed25519_priv.pem')
device_pub_path = os.path.join(KEY_DIR, 'device_ed25519_pub.pem')
device_reg = os.path.join(KEY_DIR, 'device_registry.json')

def load_or_create_device_key():
    if os.path.exists(device_priv_path):
        with open(device_priv_path,'rb') as f:
            priv = Ed25519PrivateKey.from_private_bytes(f.read())
    else:
        priv = Ed25519PrivateKey.generate()
        with open(device_priv_path,'wb') as f:
            f.write(priv.private_bytes(
                encoding=serialization.Encoding.Raw,
                format=serialization.PrivateFormat.Raw,
                encryption_algorithm=serialization.NoEncryption()
            ))
        pub = priv.public_key()
        with open(device_pub_path,'wb') as f:
            f.write(pub.public_bytes(encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw))
    return priv

dev_priv = load_or_create_device_key()
dev_pub = dev_priv.public_key()
# register device in server registry (for demo only)
reg = {}
if os.path.exists(device_reg):
    reg = json.load(open(device_reg,'r'))
reg[device_id] = {'ed25519_pub_raw': dev_pub.public_bytes(encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw).hex()}
open(device_reg,'w').write(json.dumps(reg))

def hkdf_derive(shared_secret: bytes, info: bytes=b'hippocampus demo', length=32):
    hk = HKDF(algorithm=hashes.SHA256(), length=length, salt=None, info=info)
    return hk.derive(shared_secret)

def send_message(sock, payload: bytes):
    hdr = struct.pack('!I', len(payload))
    sock.sendall(hdr + payload)

def recv_exact(sock, n):
    data = b''
    while len(data) < n:
        chunk = sock.recv(n - len(data))
        if not chunk:
            raise ConnectionError('connection closed')
        data += chunk
    return data

def recv_message(sock):
    hdr = recv_exact(sock,4)
    (length,) = struct.unpack('!I', hdr)
    return recv_exact(sock, length)

def run_client():
    # create ephemeral x25519 key pair
    xpriv = X25519PrivateKey.generate()
    xpub = xpriv.public_key().public_bytes(encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw)
    nonce = secrets.token_bytes(16)
    # attestation: sign (client_xpub || device_pub || nonce)
    device_pub_raw = dev_pub.public_bytes(encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw)
    att_blob = xpub + device_pub_raw + nonce
    att_sig = dev_priv.sign(att_blob)
    # build initial payload
    init = {'xpub': xpub.hex(), 'attest_hex': att_sig.hex(), 'device_pub_raw': device_pub_raw.hex(), 'device_id': device_id, 'nonce_hex': nonce.hex()}
    with socket.create_connection((HOST, PORT)) as sock:
        send_message(sock, json.dumps(init).encode())
        reply = json.loads(recv_message(sock).decode())
        if 'error' in reply:
            print('server error:', reply)
            return
        server_xpub = bytes.fromhex(reply['server_xpub'])
        server_sig = bytes.fromhex(reply['server_sig_hex'])
        # compute shared secret and derive session key
        shared = xpriv.exchange(X25519PublicKey.from_public_bytes(server_xpub))
        session_key = hkdf_derive(shared, info=b'session key hippocampus')
        aead = ChaCha20Poly1305(session_key[:32])
        # now send encrypted messages with seq numbers
        seq = 0
        def send_cmd(cmd):
            nonlocal seq
            seq += 1
            obj = {'seq': seq, 'cmd': cmd, 'ts': time.time()}
            nonce_out = secrets.token_bytes(12)
            ct = aead.encrypt(nonce_out, json.dumps(obj).encode(), None)
            send_message(sock, nonce_out + ct)
            # receive response
            resp = recv_message(sock)
            iv = resp[:12]; ct = resp[12:]; plain = aead.decrypt(iv, ct, None)
            print('[<-]', plain.decode())
        send_cmd('ping')
        send_cmd('request_firmware_manifest')
        time.sleep(0.2)
        send_cmd('shutdown')
        print('[*] client finished')

if __name__ == '__main__':
    run_client()
