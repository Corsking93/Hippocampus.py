
#!/usr/bin/env python3
"""hippocampus.py - Secure demo server for simulated implant communication.
This is a simulation-only server showing strong cryptographic protections:
- X25519 ECDH for ephemeral symmetric keys
- Ed25519 keys for attestation signatures
- HMAC + AEAD (ChaCha20-Poly1305) for confidentiality/integrity
- Signed firmware manifest verification
- Replay protection via nonces and sequence numbers
Usage: python3 hippocampus.py
"""

import socket, os, json, struct, secrets, time
from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey, X25519PublicKey
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives.ciphers.aead import ChaCha20Poly1305

HOST = '127.0.0.1'
PORT = 9000

# Load / generate server keys (persisted to files in demo directory)
KEY_DIR = '/mnt/data/hippocampus_secure_demo/keys'
os.makedirs(KEY_DIR, exist_ok=True)
server_priv_path = os.path.join(KEY_DIR, 'server_ed25519_priv.pem')
server_pub_path = os.path.join(KEY_DIR, 'server_ed25519_pub.pem')

def load_or_create_ed25519():
    if os.path.exists(server_priv_path):
        with open(server_priv_path,'rb') as f:
            priv = Ed25519PrivateKey.from_private_bytes(f.read())
    else:
        priv = Ed25519PrivateKey.generate()
        with open(server_priv_path,'wb') as f:
            f.write(priv.private_bytes(
                encoding=serialization.Encoding.Raw,
                format=serialization.PrivateFormat.Raw,
                encryption_algorithm=serialization.NoEncryption()
            ))
        pub = priv.public_key()
        with open(server_pub_path,'wb') as f:
            f.write(pub.public_bytes(encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw))
    return priv

server_priv = load_or_create_ed25519()
server_pub = server_priv.public_key()

def hkdf_derive(shared_secret: bytes, info: bytes=b'hippocampus demo', length=32):
    hk = HKDF(algorithm=hashes.SHA256(), length=length, salt=None, info=info)
    return hk.derive(shared_secret)

def recv_exact(conn, n):
    data = b''
    while len(data) < n:
        chunk = conn.recv(n - len(data))
        if not chunk:
            raise ConnectionError('Connection closed')
        data += chunk
    return data

def recv_message(conn):
    # protocol: 4-byte length, then payload
    hdr = recv_exact(conn, 4)
    (length,) = struct.unpack('!I', hdr)
    payload = recv_exact(conn, length)
    return payload

def send_message(conn, payload: bytes):
    hdr = struct.pack('!I', len(payload))
    conn.sendall(hdr + payload)

def handle_client(conn, addr):
    print(f"[+] connection from {addr}")
    try:
        # 1) Receive client's ephemeral X25519 public key and attestation
        payload = recv_message(conn)
        obj = json.loads(payload.decode())
        client_xpub_b64 = obj['xpub']
        attestation = bytes.fromhex(obj['attest_hex'])
        device_pub_raw = bytes.fromhex(obj['device_pub_raw'])

        # reconstruct client X25519 public key
        client_xpub = X25519PublicKey.from_public_bytes(bytes.fromhex(client_xpub_b64))
        # perform ECDH
        server_xpriv = X25519PrivateKey.generate()
        shared = server_xpriv.exchange(client_xpub)
        session_key = hkdf_derive(shared, info=b'session key hippocampus')

        # verify attestation: device signs (client_xpub || device_pub_raw || nonce) with Ed25519
        # For demo, the server trusts a pre-registered device public key file
        device_registry = os.path.join(KEY_DIR, 'device_registry.json')
        if not os.path.exists(device_registry):
            send_message(conn, b'{"error":"no devices registered on server"}')
            return
        registry = json.load(open(device_registry,'r'))
        device_id = obj['device_id']
        if device_id not in registry:
            send_message(conn, b'{"error":"unknown device id"}')
            return
        device_pub_raw_expected = bytes.fromhex(registry[device_id]['ed25519_pub_raw'])
        if device_pub_raw_expected != bytes.fromhex(device_pub_raw):
            send_message(conn, b'{"error":"pubkey mismatch"}')
            return
        dev_pub = Ed25519PublicKey.from_public_bytes(device_pub_raw_expected)
        # verify attestation signature over client_xpub + device_pub_raw + nonce
        nonce = bytes.fromhex(obj['nonce_hex'])
        verify_blob = bytes.fromhex(client_xpub_b64) + device_pub_raw_expected + nonce
        try:
            dev_pub.verify(attestation, verify_blob)
        except Exception as e:
            send_message(conn, b'{"error":"attestation failed"}')
            print("[-] attestation failed:", e)
            return
        print("[*] attestation OK")

        # send server ephemeral pubkey and server signature over (server_xpub || nonce || device_id)
        server_xpub = server_xpriv.public_key().public_bytes(encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw)
        server_signature = server_priv.sign(server_xpub + nonce + device_id.encode())

        reply = {'server_xpub': server_xpub.hex(), 'server_sig_hex': server_signature.hex()}
        send_message(conn, json.dumps(reply).encode())

        # Now both sides derive session_key. Use ChaCha20Poly1305 for AEAD
        aead = ChaCha20Poly1305(session_key[:32])

        # Exchange encrypted channel messages with sequence numbers and replay protection
        seq = 0
        while True:
            payload = recv_message(conn)
            # decrypt: payload structure => 12-byte nonce || ciphertext
            if len(payload) < 12:
                send_message(conn, b'{"error":"msg too short"}')
                break
            iv = payload[:12]
            ct = payload[12:]
            try:
                plain = aead.decrypt(iv, ct, None)
            except Exception as e:
                send_message(conn, b'{"error":"decryption failed"}')
                print("[-] decryption failed", e)
                break
            msg_obj = json.loads(plain.decode())
            # simple replay/seq check
            if msg_obj.get('seq', -1) <= seq:
                send_message(conn, b'{"error":"replay detected"}')
                break
            seq = msg_obj['seq']
            cmd = msg_obj.get('cmd')
            print(f"[>] got cmd seq={seq}: {cmd}")
            if cmd == 'ping':
                resp = {'seq': seq+1, 'resp': 'pong', 'ts': time.time()}
            elif cmd == 'request_firmware_manifest':
                # server sends signed firmware manifest with hash and signature
                manifest = {'version': '0.1.0', 'hash_sha256': 'deadbeefcafef00d... (placeholder)'}
                sig = server_priv.sign(json.dumps(manifest).encode())
                resp = {'seq': seq+1, 'manifest': manifest, 'manifest_sig_hex': sig.hex()}
            elif cmd == 'shutdown':
                resp = {'seq': seq+1, 'resp': 'ack shutdown'}
                # send encrypted response then break
                nonce_out = secrets.token_bytes(12)
                ct_out = aead.encrypt(nonce_out, json.dumps(resp).encode(), None)
                send_message(conn, nonce_out + ct_out)
                break
            else:
                resp = {'seq': seq+1, 'resp': f'unknown cmd {cmd}'}
            nonce_out = secrets.token_bytes(12)
            ct_out = aead.encrypt(nonce_out, json.dumps(resp).encode(), None)
            send_message(conn, nonce_out + ct_out)

    except Exception as e:
        print("[-] exception handling client:", e)
    finally:
        conn.close()
        print("[*] connection closed")

def run_server():
    print("[*] hippocampus secure demo server starting on", HOST, PORT)
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind((HOST, PORT))
        s.listen(5)
        while True:
            conn, addr = s.accept()
            handle_client(conn, addr)

if __name__ == '__main__':
    run_server()
